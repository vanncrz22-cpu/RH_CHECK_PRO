@echo off
setlocal
wsl bash -lc "cd \"$(wslpath '%~dp0')\" && chmod +x build_apk.sh && ./build_apk.sh"
if errorlevel 1 (
  echo.
  echo La compilacion fallo. Revisa el mensaje anterior.
  pause
  exit /b 1
)
echo.
echo APK generado en la carpeta bin.
pause
