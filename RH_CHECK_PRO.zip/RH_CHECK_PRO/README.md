# RH CHECK 2.1 – Gestión de asistencia y personal

Aplicación Android desarrollada con **Python + Kivy + SQLite**.

## Compilar el APK con un solo comando

### Si usas Windows

La forma recomendada es **WSL2 + Ubuntu**, porque Buildozer necesita un entorno Linux para empaquetar Android. La documentación actual de Buildozer indica que en Windows se utiliza WSL y recomienda compilar dentro del filesystem Linux, no directamente sobre `C:`. 

1. Instala WSL2 y Ubuntu si todavía no los tienes. Desde PowerShell como administrador:

```powershell
wsl --install -d Ubuntu
```

Reinicia Windows si te lo solicita y abre Ubuntu una vez para completar su configuración.

2. Descomprime este proyecto.

3. Desde el Explorador de Windows, entra a la carpeta `RH_CHECK_PRO` y haz doble clic en:

```text
build_apk.bat
```

El script instala/prepara las dependencias necesarias, copia el proyecto al filesystem Linux, ejecuta Buildozer y devuelve el APK a la carpeta:

```text
RH_CHECK_PRO\bin\
```

También puedes abrir Ubuntu/WSL en esta carpeta y ejecutar:

```bash
./build_apk.sh
```

### Si ya tienes Buildozer configurado

Basta con:

```bash
buildozer -v android debug
```

El resultado se coloca en `bin/`.

## Qué hace `build_apk.sh`

- Comprueba que se está ejecutando en Linux/WSL2.
- Instala dependencias de sistema cuando está disponible `apt`.
- Prepara Rust si es necesario.
- Crea un entorno virtual aislado para Buildozer.
- Instala Buildozer y Cython compatible.
- Copia el proyecto al filesystem Linux para evitar los problemas de rendimiento/permisos de `/mnt/c`.
- Ejecuta la compilación Android en modo debug.
- Copia los APK generados de vuelta a `bin/` del proyecto.

La primera compilación puede tardar bastante porque Buildozer descarga el SDK/NDK y otras herramientas de Android. Las compilaciones posteriores suelen ser mucho más rápidas.

## Funciones de RH CHECK

- Dashboard de trabajadores y asistencia.
- Alta y actualización de trabajadores.
- Área y puesto independientes para cada trabajador.
- Registro de entrada y salida.
- Validación de número de empleado.
- Prevención de registros duplicados.
- Evaluaciones de desempeño de 1 a 10.
- Reportes por fecha.
- Exportación CSV compatible con Excel.
- Respaldo de SQLite.
- Funcionamiento local sin internet para las funciones básicas.

## Estructura

```text
RH_CHECK_PRO/
├── main.py
├── buildozer.spec
├── build_apk.sh
├── build_apk.bat
├── build_apk.ps1
├── requirements-build.txt
└── README.md
```

## APK de depuración vs. versión empresarial

El APK generado con `debug` sirve para pruebas e instalación directa en Android. Para distribución empresarial se recomienda después generar una versión firmada (`release`) y, si se publicará en una tienda, configurar firma, privacidad, almacenamiento seguro y una base de datos/API central para sincronizar varios dispositivos.
