#!/usr/bin/env bash
set -euo pipefail

# RH CHECK - constructor de APK para Linux/WSL.
# Ejecutar desde la carpeta del proyecto: ./build_apk.sh

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_NAME="RH_CHECK_PRO"
BUILD_DIR="$HOME/rhcheck_android_build/$PROJECT_NAME"

printf '\n=============================================\n'
printf ' RH CHECK 2.1 - CONSTRUCTOR DE APK\n'
printf '=============================================\n\n'

if [[ "${WSL_DISTRO_NAME:-}" != "" ]]; then
  echo "Entorno detectado: WSL ($WSL_DISTRO_NAME)"
else
  echo "Entorno detectado: Linux"
fi

echo "Proyecto: $PROJECT_DIR"
echo "Compilación: $BUILD_DIR"
echo

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "ERROR: este script debe ejecutarse en Linux o WSL2."
  exit 1
fi

# Dependencias del sistema. Se instala solo lo que falte.
if command -v apt-get >/dev/null 2>&1; then
  echo "[1/6] Comprobando dependencias del sistema..."
  sudo apt-get update
  sudo apt-get install -y git zip unzip openjdk-17-jdk python3-pip python3-venv \
    autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev \
    libtinfo6 cmake libffi-dev libssl-dev automake autopoint gettext curl
else
  echo "AVISO: no se encontró apt-get. Instala manualmente Python 3, Java 17, git, zip/unzip y las dependencias de Buildozer."
fi

# Rust es requerido por las versiones actuales del toolchain Android en algunos entornos.
if ! command -v cargo >/dev/null 2>&1; then
  echo "[2/6] Instalando Rust..."
  curl https://sh.rustup.rs -sSf | sh -s -- -y
  # shellcheck disable=SC1091
  source "$HOME/.cargo/env"
else
  echo "[2/6] Rust ya está instalado."
fi

export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"

# Buildozer/p4a se ejecutan en el filesystem Linux para evitar problemas de rendimiento/permisos en /mnt/c.
echo "[3/6] Preparando copia de trabajo en el filesystem Linux..."
rm -rf "$BUILD_DIR"
mkdir -p "$(dirname "$BUILD_DIR")"
cp -a "$PROJECT_DIR" "$BUILD_DIR"
cd "$BUILD_DIR"
rm -rf .buildozer bin

# Entorno virtual aislado para el constructor.
VENV="$HOME/rhcheck_android_build/.venv"
if [[ ! -d "$VENV" ]]; then
  echo "[4/6] Creando entorno Python para Buildozer..."
  python3 -m venv "$VENV"
fi
# shellcheck disable=SC1091
source "$VENV/bin/activate"
python -m pip install --upgrade pip setuptools wheel
python -m pip install --upgrade buildozer "cython==0.29.34"

# Aceptación no interactiva de licencias cuando la herramienta lo permite.
export PIP_DISABLE_PIP_VERSION_CHECK=1

echo "[5/6] Compilando APK. La primera compilación puede tardar bastante..."
buildozer -v android debug

echo "[6/6] Copiando APK al proyecto original..."
mkdir -p "$PROJECT_DIR/bin"
shopt -s nullglob
APKS=("$BUILD_DIR"/bin/*.apk)
if (( ${#APKS[@]} == 0 )); then
  echo "ERROR: Buildozer terminó pero no se encontró ningún APK en $BUILD_DIR/bin/"
  exit 2
fi
for apk in "${APKS[@]}"; do
  cp -f "$apk" "$PROJECT_DIR/bin/"
done

printf '\n=============================================\n'
printf ' APK GENERADO CORRECTAMENTE\n'
printf '=============================================\n'
ls -lh "$PROJECT_DIR"/bin/*.apk
printf '\nEl APK está en: %s/bin/\n' "$PROJECT_DIR"
printf '=============================================\n\n'
