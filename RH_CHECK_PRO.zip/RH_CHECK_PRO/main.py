__version__ = "2.1.0"
from datetime import datetime, date
import csv
import sqlite3
from pathlib import Path

from kivy.app import App
from kivy.lang import Builder
from kivy.metrics import dp
from kivy.properties import StringProperty
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.popup import Popup
from kivy.uix.label import Label

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "rh_check.db"
EXPORT_DIR = APP_DIR / "reportes"
EXPORT_DIR.mkdir(exist_ok=True)

KV = r'''
#:import dp kivy.metrics.dp

<PrimaryButton@Button>:
    background_normal: ''
    background_color: .08,.35,.65,1
    color: 1,1,1,1
    bold: True
    size_hint_y: None
    height: dp(48)

<SuccessButton@Button>:
    background_normal: ''
    background_color: .10,.65,.42,1
    color: 1,1,1,1
    bold: True
    size_hint_y: None
    height: dp(48)

<DangerButton@Button>:
    background_normal: ''
    background_color: .90,.25,.35,1
    color: 1,1,1,1
    bold: True
    size_hint_y: None
    height: dp(46)

<LightButton@Button>:
    background_normal: ''
    background_color: .88,.94,1,1
    color: .06,.20,.38,1
    bold: True
    size_hint_y: None
    height: dp(46)

<TitleLabel@Label>:
    color: .04,.14,.28,1
    bold: True
    font_size: '24sp'
    size_hint_y: None
    height: dp(45)

<Header@BoxLayout>:
    size_hint_y: None
    height: dp(58)
    padding: dp(12)
    spacing: dp(8)
    canvas.before:
        Color:
            rgba: .05,.22,.40,1
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: app.header_title
        color: 1,1,1,1
        bold: True
        font_size: '18sp'
    Button:
        text: '⌂'
        size_hint_x: None
        width: dp(45)
        background_normal: ''
        background_color: 0,0,0,0
        color: 1,1,1,1
        font_size: '23sp'
        on_release: app.go('home')

<Field@TextInput>:
    multiline: False
    size_hint_y: None
    height: dp(44)
    padding: dp(10), dp(10)

<HomeScreen>:
    BoxLayout:
        orientation: 'vertical'
        padding: dp(18)
        spacing: dp(10)
        canvas.before:
            Color:
                rgba: .96,.98,1,1
            Rectangle:
                pos: self.pos
                size: self.size
        Widget:
            size_hint_y: .04
        TitleLabel:
            text: 'RH CHECK'
        Label:
            text: 'Gestión de asistencia y seguimiento del personal'
            color: .15,.25,.38,1
            size_hint_y: None
            height: dp(34)
        BoxLayout:
            size_hint_y: None
            height: dp(82)
            spacing: dp(10)
            Label:
                text: 'TRABAJADORES\n' + str(app.total_workers)
                color: .08,.22,.38,1
                bold: True
            Label:
                text: 'PRESENTES HOY\n' + str(app.present_today)
                color: .05,.48,.28,1
                bold: True
            Label:
                text: 'INCIDENCIAS\n' + str(app.incidents_today)
                color: .75,.24,.12,1
                bold: True
        PrimaryButton:
            text: 'Registrar asistencia'
            on_release: app.go('attendance')
        PrimaryButton:
            text: 'Personal / áreas / puestos'
            on_release: app.go('employees')
        PrimaryButton:
            text: 'Evaluaciones y seguimiento'
            on_release: app.go('evaluations')
        PrimaryButton:
            text: 'Reportes y exportación'
            on_release: app.go('reports')
        LightButton:
            text: 'Configuración / respaldo'
            on_release: app.go('settings')
        Widget:

<AttendanceScreen>:
    BoxLayout:
        orientation: 'vertical'
        Header:
        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(16)
                spacing: dp(9)
                size_hint_y: None
                height: self.minimum_height
                Label:
                    text: 'REGISTRO DE ASISTENCIA'
                    bold: True
                    color: .05,.20,.36,1
                    size_hint_y: None
                    height: dp(35)
                Label:
                    text: 'Número de empleado'
                    size_hint_y: None
                    height: dp(25)
                Field:
                    id: att_emp
                    hint_text: 'Ej. 001'
                PrimaryButton:
                    text: 'Registrar entrada ahora'
                    on_release: app.clock_in(att_emp.text)
                PrimaryButton:
                    text: 'Registrar salida ahora'
                    on_release: app.clock_out(att_emp.text)
                Label:
                    text: 'Consulta rápida'
                    bold: True
                    size_hint_y: None
                    height: dp(30)
                Field:
                    id: att_search
                    hint_text: 'Número de empleado'
                LightButton:
                    text: 'Ver asistencia de hoy'
                    on_release: app.show_today(att_search.text)
                Label:
                    id: att_status
                    text: 'Aquí aparecerá el resultado.'
                    color: .08,.25,.40,1
                    text_size: self.width, None
                    size_hint_y: None
                    height: dp(90)

<EmployeesScreen>:
    BoxLayout:
        orientation: 'vertical'
        Header:
        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(16)
                spacing: dp(8)
                size_hint_y: None
                height: self.minimum_height
                Label:
                    text: 'ALTA Y CONSULTA DE PERSONAL'
                    bold: True
                    color: .05,.20,.36,1
                    size_hint_y: None
                    height: dp(35)
                Field:
                    id: e_id
                    hint_text: 'No. de empleado *'
                Field:
                    id: e_name
                    hint_text: 'Nombre completo *'
                Field:
                    id: e_area
                    hint_text: 'Área * (ej. Producción)'
                Field:
                    id: e_position
                    hint_text: 'Puesto * (ej. Operador)'
                Field:
                    id: e_phone
                    hint_text: 'Teléfono'
                Field:
                    id: e_email
                    hint_text: 'Correo electrónico'
                Field:
                    id: e_age
                    hint_text: 'Edad'
                    input_filter: 'int'
                PrimaryButton:
                    text: 'Guardar / actualizar trabajador'
                    on_release: app.save_employee(e_id.text,e_name.text,e_area.text,e_position.text,e_phone.text,e_email.text,e_age.text)
                LightButton:
                    text: 'Listar trabajadores'
                    on_release: app.list_employees()
                Label:
                    id: e_list
                    text: 'No hay resultados todavía.'
                    text_size: self.width, None
                    size_hint_y: None
                    height: dp(260)
                    color: .08,.18,.30,1

<EvaluationsScreen>:
    BoxLayout:
        orientation: 'vertical'
        Header:
        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(16)
                spacing: dp(8)
                size_hint_y: None
                height: self.minimum_height
                Label:
                    text: 'EVALUACIÓN Y SEGUIMIENTO'
                    bold: True
                    color: .05,.20,.36,1
                    size_hint_y: None
                    height: dp(35)
                Field:
                    id: ev_emp
                    hint_text: 'No. de empleado *'
                Field:
                    id: ev_score
                    hint_text: 'Calificación 1-10 *'
                    input_filter: 'float'
                Field:
                    id: ev_type
                    hint_text: 'Tipo de evaluación (desempeño, puntualidad...)'
                Field:
                    id: ev_notes
                    hint_text: 'Observaciones'
                    multiline: True
                    height: dp(90)
                PrimaryButton:
                    text: 'Guardar evaluación'
                    on_release: app.save_evaluation(ev_emp.text,ev_score.text,ev_type.text,ev_notes.text)
                LightButton:
                    text: 'Ver evaluaciones del trabajador'
                    on_release: app.list_evaluations(ev_emp.text)
                Label:
                    id: ev_list
                    text: 'Las evaluaciones aparecerán aquí.'
                    text_size: self.width, None
                    size_hint_y: None
                    height: dp(300)

<ReportsScreen>:
    BoxLayout:
        orientation: 'vertical'
        Header:
        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(16)
                spacing: dp(9)
                size_hint_y: None
                height: self.minimum_height
                Label:
                    text: 'REPORTES Y EXPORTACIÓN'
                    bold: True
                    color: .05,.20,.36,1
                    size_hint_y: None
                    height: dp(35)
                Field:
                    id: rep_date
                    hint_text: 'Fecha YYYY-MM-DD (vacío = hoy)'
                PrimaryButton:
                    text: 'Resumen de asistencia'
                    on_release: app.report_attendance(rep_date.text)
                PrimaryButton:
                    text: 'Exportar asistencia CSV'
                    on_release: app.export_attendance(rep_date.text)
                PrimaryButton:
                    text: 'Exportar trabajadores CSV'
                    on_release: app.export_workers()
                PrimaryButton:
                    text: 'Exportar evaluaciones CSV'
                    on_release: app.export_evaluations()
                Label:
                    id: rep_status
                    text: 'Los archivos se guardan en la carpeta reportes de la aplicación.'
                    text_size: self.width, None
                    size_hint_y: None
                    height: dp(180)

<SettingsScreen>:
    BoxLayout:
        orientation: 'vertical'
        Header:
        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(16)
                spacing: dp(9)
                size_hint_y: None
                height: self.minimum_height
                Label:
                    text: 'CONFIGURACIÓN Y RESPALDO'
                    bold: True
                    color: .05,.20,.36,1
                    size_hint_y: None
                    height: dp(35)
                PrimaryButton:
                    text: 'Crear respaldo de la base de datos'
                    on_release: app.backup_db()
                LightButton:
                    text: 'Restaurar base desde archivo CSV no incluido'
                    on_release: app.info('La restauración automática puede agregarse en una siguiente versión.')
                Label:
                    text: 'Buenas prácticas: realizar respaldos periódicos y limitar el acceso administrativo.\n\nEl sistema valida campos vacíos, números de empleado inexistentes, duplicados y registros de asistencia duplicados.'
                    text_size: self.width, None
                    size_hint_y: None
                    height: dp(180)

ScreenManager:
    HomeScreen:
        name: 'home'
    AttendanceScreen:
        name: 'attendance'
    EmployeesScreen:
        name: 'employees'
    EvaluationsScreen:
        name: 'evaluations'
    ReportsScreen:
        name: 'reports'
    SettingsScreen:
        name: 'settings'
'''

class HomeScreen(Screen): pass
class AttendanceScreen(Screen): pass
class EmployeesScreen(Screen): pass
class EvaluationsScreen(Screen): pass
class ReportsScreen(Screen): pass
class SettingsScreen(Screen): pass

class RHCheckApp(App):
    header_title = StringProperty('RH CHECK')
    total_workers = 0
    present_today = 0
    incidents_today = 0

    def build(self):
        self.title = 'RH CHECK'
        self.db = sqlite3.connect(DB_PATH)
        self.db.row_factory = sqlite3.Row
        self.init_db()
        self.refresh_stats()
        Builder.load_string(KV)
        return ScreenManager.current if False else self.root_manager_placeholder()

    def root_manager_placeholder(self):
        # KV's root is the ScreenManager; Builder.load_string must create it.
        from kivy.factory import Factory
        return Factory.ScreenManager()

    def on_start(self):
        self.refresh_stats()

    def init_db(self):
        c = self.db.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS employees (
            employee_id TEXT PRIMARY KEY, name TEXT NOT NULL, area TEXT NOT NULL,
            position TEXT NOT NULL, phone TEXT, email TEXT, age INTEGER,
            active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL,
            work_date TEXT NOT NULL, entry_time TEXT, exit_time TEXT,
            status TEXT NOT NULL DEFAULT 'Presente', UNIQUE(employee_id, work_date),
            FOREIGN KEY(employee_id) REFERENCES employees(employee_id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS evaluations (
            id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL,
            eval_date TEXT NOT NULL, score REAL NOT NULL, eval_type TEXT,
            notes TEXT, FOREIGN KEY(employee_id) REFERENCES employees(employee_id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT,
            incident_date TEXT NOT NULL, category TEXT NOT NULL,
            description TEXT NOT NULL, resolved INTEGER DEFAULT 0)''')
        # Demo data, only when empty
        if c.execute('SELECT COUNT(*) FROM employees').fetchone()[0] == 0:
            demo = [
                ('001','Ana López','Recursos Humanos','Supervisor general','777 123 4567','ana.lopez@empresa.com',19),
                ('002','Carlos Méndez','Producción','Operador','777 234 5678','carlos.mendez@empresa.com',28),
                ('003','Mariana Torres','Ventas','Ejecutiva de ventas','777 345 6789','mariana.torres@empresa.com',25),
                ('004','Luis Hernández','Mantenimiento','Técnico','777 456 7890','luis.hernandez@empresa.com',31)]
            now = datetime.now().isoformat(timespec='seconds')
            c.executemany('INSERT INTO employees(employee_id,name,area,position,phone,email,age,created_at) VALUES(?,?,?,?,?,?,?,?)',
                          [x+(now,) for x in demo])
        self.db.commit()

    def refresh_stats(self):
        if not hasattr(self, 'db'): return
        today = date.today().isoformat()
        self.total_workers = self.db.execute('SELECT COUNT(*) FROM employees WHERE active=1').fetchone()[0]
        self.present_today = self.db.execute("SELECT COUNT(*) FROM attendance WHERE work_date=? AND entry_time IS NOT NULL", (today,)).fetchone()[0]
        self.incidents_today = self.db.execute('SELECT COUNT(*) FROM incidents WHERE incident_date=? AND resolved=0', (today,)).fetchone()[0]
        try:
            self.root.current = 'home'
        except Exception:
            pass

    def go(self, screen):
        self.root.current = screen
        self.header_title = {'home':'RH CHECK','attendance':'Registro de asistencia','employees':'Personal','evaluations':'Evaluaciones','reports':'Reportes','settings':'Configuración'}.get(screen,'RH CHECK')
        self.refresh_stats()

    def popup(self, title, msg):
        Popup(title=title, content=Label(text=msg, text_size=(dp(300), None)), size_hint=(.88,.35)).open()

    def info(self, msg): self.popup('RH CHECK', msg)

    def employee_exists(self, eid):
        return self.db.execute('SELECT * FROM employees WHERE employee_id=? AND active=1',(eid,)).fetchone()

    def clock_in(self, eid):
        eid = eid.strip()
        if not eid: return self.info('Escribe el número de empleado.')
        emp = self.employee_exists(eid)
        if not emp: return self.info('Error: el número de empleado no existe o está inactivo.')
        now = datetime.now(); d = now.date().isoformat(); t = now.strftime('%H:%M:%S')
        row = self.db.execute('SELECT * FROM attendance WHERE employee_id=? AND work_date=?',(eid,d)).fetchone()
        if row and row['entry_time']:
            return self.info(f"La entrada de {emp['name']} ya fue registrada a las {row['entry_time']}.")
        if row:
            self.db.execute('UPDATE attendance SET entry_time=?,status=? WHERE id=?',(t,'Presente',row['id']))
        else:
            self.db.execute('INSERT INTO attendance(employee_id,work_date,entry_time,status) VALUES(?,?,?,?)',(eid,d,t,'Presente'))
        self.db.commit(); self.refresh_stats()
        self.root.get_screen('attendance').ids.att_status.text = f"✓ Entrada registrada\n{emp['name']} — {emp['area']} — {emp['position']}\nFecha: {d}  Hora: {t}"

    def clock_out(self, eid):
        eid = eid.strip(); emp = self.employee_exists(eid)
        if not emp: return self.info('Error: el número de empleado no existe o está inactivo.')
        now = datetime.now(); d = now.date().isoformat(); t = now.strftime('%H:%M:%S')
        row = self.db.execute('SELECT * FROM attendance WHERE employee_id=? AND work_date=?',(eid,d)).fetchone()
        if not row or not row['entry_time']:
            return self.info('Primero debe existir una entrada registrada.')
        if row['exit_time']:
            return self.info(f"La salida ya fue registrada a las {row['exit_time']}.")
        self.db.execute('UPDATE attendance SET exit_time=? WHERE id=?',(t,row['id']))
        self.db.commit(); self.refresh_stats()
        self.root.get_screen('attendance').ids.att_status.text = f"✓ Salida registrada\n{emp['name']}\nEntrada: {row['entry_time']}  Salida: {t}"

    def show_today(self, eid):
        eid=eid.strip(); d=date.today().isoformat()
        if eid:
            row=self.db.execute('''SELECT a.*,e.name,e.area,e.position FROM attendance a JOIN employees e ON e.employee_id=a.employee_id WHERE a.employee_id=? AND a.work_date=?''',(eid,d)).fetchone()
        else: row=None
        if not row: return self.info('No hay registro de asistencia para ese trabajador en la fecha de hoy.')
        self.root.get_screen('attendance').ids.att_status.text = f"{row['name']}\nÁrea: {row['area']}\nPuesto: {row['position']}\nEntrada: {row['entry_time'] or '—'}\nSalida: {row['exit_time'] or '—'}\nEstado: {row['status']}"

    def save_employee(self,eid,name,area,position,phone,email,age):
        vals=[x.strip() for x in [eid,name,area,position]]
        if not all(vals): return self.info('Completa No. de empleado, nombre, área y puesto.')
        try: agev=int(age) if age.strip() else None
        except ValueError: return self.info('La edad debe ser numérica.')
        now=datetime.now().isoformat(timespec='seconds')
        exists=self.db.execute('SELECT employee_id FROM employees WHERE employee_id=?',(eid,)).fetchone()
        if exists:
            self.db.execute('''UPDATE employees SET name=?,area=?,position=?,phone=?,email=?,age=?,active=1 WHERE employee_id=?''',(name,area,position,phone,email,agev,eid))
            msg='Trabajador actualizado correctamente.'
        else:
            self.db.execute('''INSERT INTO employees(employee_id,name,area,position,phone,email,age,created_at) VALUES(?,?,?,?,?,?,?,?)''',(eid,name,area,position,phone,email,agev,now))
            msg='Trabajador registrado correctamente.'
        self.db.commit(); self.refresh_stats(); self.list_employees(); self.info(msg)

    def list_employees(self):
        rows=self.db.execute('SELECT * FROM employees WHERE active=1 ORDER BY area,name').fetchall()
        text='\n'.join([f"{r['employee_id']} | {r['name']} | {r['area']} | {r['position']}" for r in rows]) or 'Sin trabajadores.'
        self.root.get_screen('employees').ids.e_list.text=text

    def save_evaluation(self,eid,score,etype,notes):
        emp=self.employee_exists(eid.strip())
        if not emp: return self.info('El número de empleado no existe.')
        try: s=float(score)
        except ValueError: return self.info('La calificación debe ser numérica.')
        if not 1 <= s <= 10: return self.info('La calificación debe estar entre 1 y 10.')
        self.db.execute('INSERT INTO evaluations(employee_id,eval_date,score,eval_type,notes) VALUES(?,?,?,?,?)',(eid.strip(),date.today().isoformat(),s,etype.strip() or 'Desempeño',notes.strip()))
        self.db.commit(); self.list_evaluations(eid); self.info('Evaluación guardada correctamente.')

    def list_evaluations(self,eid):
        rows=self.db.execute('''SELECT v.*,e.name FROM evaluations v JOIN employees e ON e.employee_id=v.employee_id WHERE v.employee_id=? ORDER BY v.eval_date DESC''',(eid.strip(),)).fetchall()
        text='\n'.join([f"{r['eval_date']} | {r['score']}/10 | {r['eval_type']}\n{r['notes']}" for r in rows]) or 'Sin evaluaciones.'
        self.root.get_screen('evaluations').ids.ev_list.text=text

    def report_attendance(self,ds):
        ds=ds.strip() or date.today().isoformat()
        rows=self.db.execute('''SELECT a.*,e.name,e.area,e.position FROM attendance a JOIN employees e ON e.employee_id=a.employee_id WHERE a.work_date=? ORDER BY e.area,e.name''',(ds,)).fetchall()
        if not rows: return self.info(f'No hay asistencia registrada para {ds}.')
        text=f'ASISTENCIA {ds}\n\n'+ '\n'.join([f"{r['employee_id']} {r['name']} | {r['area']} | Entrada {r['entry_time'] or '—'} | Salida {r['exit_time'] or '—'}" for r in rows])
        self.root.get_screen('reports').ids.rep_status.text=text

    def export_attendance(self,ds):
        ds=ds.strip() or date.today().isoformat(); rows=self.db.execute('''SELECT a.work_date,a.employee_id,e.name,e.area,e.position,a.entry_time,a.exit_time,a.status FROM attendance a JOIN employees e ON e.employee_id=a.employee_id WHERE a.work_date=? ORDER BY e.area,e.name''',(ds,)).fetchall()
        path=EXPORT_DIR/f'asistencia_{ds}.csv'; self.write_csv(path, rows)
        self.root.get_screen('reports').ids.rep_status.text=f'Archivo creado:\n{path}'

    def export_workers(self):
        rows=self.db.execute('SELECT employee_id,name,area,position,phone,email,age,active,created_at FROM employees ORDER BY area,name').fetchall()
        path=EXPORT_DIR/'trabajadores.csv'; self.write_csv(path,rows); self.root.get_screen('reports').ids.rep_status.text=f'Archivo creado:\n{path}'

    def export_evaluations(self):
        rows=self.db.execute('''SELECT v.eval_date,v.employee_id,e.name,e.area,e.position,v.score,v.eval_type,v.notes FROM evaluations v JOIN employees e ON e.employee_id=v.employee_id ORDER BY v.eval_date DESC''').fetchall()
        path=EXPORT_DIR/'evaluaciones.csv'; self.write_csv(path,rows); self.root.get_screen('reports').ids.rep_status.text=f'Archivo creado:\n{path}'

    def write_csv(self,path,rows):
        with open(path,'w',newline='',encoding='utf-8-sig') as f:
            if rows:
                w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows([dict(r) for r in rows])

    def backup_db(self):
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); dest=EXPORT_DIR/f'rh_check_backup_{stamp}.db'
        self.db.commit(); import shutil; shutil.copy2(DB_PATH,dest)
        self.info(f'Respaldo creado correctamente:\n{dest}')

    def on_stop(self):
        try: self.db.close()
        except Exception: pass

if __name__ == '__main__':
    RHCheckApp().run()
